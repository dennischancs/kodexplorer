#!/usr/bin/env bash
bash upgrade.sh
bash initTools.sh 512
bash restart.sh
