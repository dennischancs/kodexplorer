#!/opt/bin/env bash

basepath=$(cd `dirname $0`; pwd)

var=$(cat .config)
arr=()
for element in $var
do
    arr[${#arr[*]}]=$element
done
echo ${arr[0]} ${arr[1]};
data=${arr[0]}
tag=${arr[1]}

export basedir=$data
export tag=$tag

basepath=$(cd `dirname $0`; pwd)

echo "up service"
docker-compose -f $basedir/service/docker-compose.yml up -d

echo "up apps"
docker-compose -f $basedir/workspace/docker-compose.yml up -d

echo "up nginx"
docker-compose -f $basedir/nginx/docker-compose.yml up -d

bash $basepath/restart.sh
