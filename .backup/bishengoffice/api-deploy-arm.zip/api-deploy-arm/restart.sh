#!/opt/bin/env bash
var=$(cat .config)
arr=()
for element in $var
do
    arr[${#arr[*]}]=$element
done
echo ${arr[0]} ${arr[1]};
data=${arr[0]}
tag=${arr[1]}

export basedir=$data
export tag=$tag

basepath=$(cd `dirname $0`; pwd)

docker-compose -f $basedir/service/docker-compose.yml restart  mongod redis rabbit minio

sleep 40

docker-compose -f $basedir/workspace/docker-compose.yml restart editor_app editor convert

sleep 20

docker-compose -f $basedir/nginx/docker-compose.yml restart nginx

