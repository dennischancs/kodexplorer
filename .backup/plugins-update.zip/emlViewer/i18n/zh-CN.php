<?php

return array(
    'emlViewer.header.subject' => "主题：",
    'emlViewer.header.from' => "发件人：",
    'emlViewer.header.to' => "收件人：",
    'emlViewer.header.cc' => "抄送：",
    'emlViewer.header.date' => "时间：",
    'emlViewer.header.attach' => "附件：",
    'emlViewer.header.size' => "大小：",
    'emlViewer.header.attach2' => "附件",
    'emlViewer.header.print' => "打印",
    'emlViewer.header.more' => "详细信息",
    'emlViewer.header.hidden' => "隐藏信息",
    'emlViewer.header.sendto' => "发给",
);