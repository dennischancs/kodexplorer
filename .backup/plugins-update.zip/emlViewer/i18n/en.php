<?php

return array(
    'emlViewer.header.subject' => "Subject:",
    'emlViewer.header.from' => "From:",
    'emlViewer.header.to' => "To:",
    'emlViewer.header.cc' => "CC:",
    'emlViewer.header.date' => "Date:",
    'emlViewer.header.attach' => "Attachment:",
    'emlViewer.header.size' => "Size:",
    'emlViewer.header.attach2' => "Attachment",
    'emlViewer.header.print' => "Print",
    'emlViewer.header.more' => "More",
    'emlViewer.header.hidden' => "Hidden",
    'emlViewer.header.sendto' => "to",
);