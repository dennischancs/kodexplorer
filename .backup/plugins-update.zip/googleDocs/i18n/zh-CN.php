<?php
return array(
	"googleDocs.meta.name"				=> "Google文档预览",
	"googleDocs.meta.title"				=> "Google文档预览",
	"googleDocs.meta.desc"				=> "Google Docs是一套在线办公软件，包括在线文档、表格和演示文稿;可以通过传入文件地址的方式提供第三方文档预览.
	<br/><br/><h4>说明:</h4>预览服务器的地址，必须要office所在服务器能访问到kod(kod服务器必须要在外网)"
);